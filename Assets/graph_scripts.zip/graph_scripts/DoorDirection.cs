public enum DoorDirection
{
    North = 0,
    East = 1,
    South = 2,
    West = 3,
    None = -1
}
